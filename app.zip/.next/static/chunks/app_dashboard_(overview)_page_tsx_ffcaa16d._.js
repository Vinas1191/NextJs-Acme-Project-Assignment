(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_(overview)_page_tsx_ffcaa16d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_(overview)_page_tsx_ffcaa16d._.js",
  "chunks": [
    "static/chunks/5bbe2_next_dist_0e893c36._.js"
  ],
  "source": "dynamic"
});
