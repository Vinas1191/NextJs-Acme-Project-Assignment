(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_layout_tsx_e75e1d9d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_layout_tsx_e75e1d9d._.js",
  "chunks": [
    "static/chunks/_d218f741._.js"
  ],
  "source": "dynamic"
});
