(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/5bbe2_next_error_824bbbfd.js", {

"[project]/node_modules/.pnpm/next@15.2.1-canary.5_react-_194d32a57b9798ca2064cf369de55895/node_modules/next/error.js [client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.2.1-canary.5_react-_194d32a57b9798ca2064cf369de55895/node_modules/next/dist/pages/_error.js [client] (ecmascript)");
}}),
}]);

//# sourceMappingURL=5bbe2_next_error_824bbbfd.js.map