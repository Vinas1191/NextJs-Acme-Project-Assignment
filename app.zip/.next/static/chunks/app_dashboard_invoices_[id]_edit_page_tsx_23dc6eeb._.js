(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_invoices_[id]_edit_page_tsx_23dc6eeb._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_invoices_[id]_edit_page_tsx_23dc6eeb._.js",
  "chunks": [
    "static/chunks/_c36c36a6._.js"
  ],
  "source": "dynamic"
});
