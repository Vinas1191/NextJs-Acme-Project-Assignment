(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_layout_tsx_e75085._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_layout_tsx_e75085._.js",
  "chunks": [
    "static/chunks/_bb6fcd._.js"
  ],
  "source": "dynamic"
});
