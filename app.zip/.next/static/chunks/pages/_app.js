__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root of the server]__bc9e8012._.js",
  "static/chunks/545c3_react-dom_1c85ba3a._.js",
  "static/chunks/node_modules__pnpm_f84813a4._.js",
  "static/chunks/[root of the server]__49fd8634._.js",
  "static/chunks/pages__app_5771e187._.js",
  "static/chunks/pages__app_cd8b344c._.js"
])
