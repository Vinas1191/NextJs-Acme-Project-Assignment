(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_invoices_error_tsx_23dc6eeb._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_invoices_error_tsx_23dc6eeb._.js",
  "chunks": [
    "static/chunks/app_dashboard_invoices_error_tsx_7e72c89d._.js"
  ],
  "source": "dynamic"
});
