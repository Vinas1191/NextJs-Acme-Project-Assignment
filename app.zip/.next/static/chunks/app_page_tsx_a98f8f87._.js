(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_a98f8f87._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_a98f8f87._.js",
  "chunks": [
    "static/chunks/5bbe2_next_dist_69d1bd96._.js"
  ],
  "source": "dynamic"
});
