(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_365dd1df._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_365dd1df._.js",
  "chunks": [
    "static/chunks/5bbe2_next_dist_69d1bd96._.js",
    "static/chunks/app_ui_home_module_6dd21efa.css"
  ],
  "source": "dynamic"
});
