const CHUNK_PUBLIC_PATH = "server/app/query/route.js";
const runtime = require("../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules__pnpm_5284c7._.js");
runtime.loadChunk("server/chunks/[root of the server]__a5661f._.js");
runtime.loadChunk("server/chunks/_726826._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/query/route/actions.js [app-rsc] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/.pnpm/next@15.1.6_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/query/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
