module.exports = {

"[project]/app/dashboard/invoices/error.tsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=app_dashboard_invoices_error_tsx_e2c20b25._.js.map